package com.longjiu.appdemo;

import android.Manifest;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.longjiu.ble.service.ArmorDeviceServiceInterface;
import com.longjiu.ble.service.BleHelper;
import com.longjiu.ble.callback.BleInitCallback;
import com.longjiu.ble.callback.DeviceTransferCallback;
import com.longjiu.ble.callback.ScanCallback;
import com.longjiu.ble.callback.add.LPFN_HS_ArmorMoveResult;
import com.longjiu.ble.callback.add.LPFN_HS_CalibrationCompleteResult;
import com.longjiu.ble.callback.add.LPFN_HS_DeviceStateChanged;
import com.longjiu.ble.callback.add.LPFN_HS_GetPowerResult;
import com.longjiu.ble.callback.add.LPFN_HS_InfraredEntry;
import com.longjiu.ble.callback.add.LPFN_HS_InfraredSustained;
import com.longjiu.ble.callback.add.LPFN_HS_LegMoveResult;
import com.longjiu.ble.callback.add.LPFN_HS_PushButtonClick;
import com.longjiu.ble.callback.add.LPFN_HS_PushButtonStick;
import com.longjiu.ble.model.BleRssiDevice;
import com.longjiu.ble.model.DeviceEnum;
import com.longjiu.ble.service.ArmorDeviceService;

import cn.com.heaton.blelibrary.ble.BleLog;
import cn.com.heaton.blelibrary.ble.utils.ByteUtils;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    static final String[] PERMISSION = new String[]{
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
    };
    private static String TAG = "@@MainActivity";
    private static final String DEVICE_ADDRESS = "AD:DF:10:00:00:02";
    private static final String DEVICE_ADDRESS_L_LEG = "AD:DF:04:00:00:02";
    private static final String DEVICE_ADDRESS_R_LEG = "AD:DF:05:00:00:02";
    private Button tv1;
    private Button tv2;
    private Button tv3;
    private Button tv4;
    private Button tv6;
    private Button tv7;
    private Button tv8;
    private static String DEMO_DATA = "" +
            "0xfa 0xfb 0x1f 0x01 0xa1 0x09 0x1a 0x14 0x31 0x33 0x38 0x2f 0x09 0x01 0x33 0x60 0x03 0x0e 0x33 0x4c 0x51 0x52 0x4e 0x11 0x01 0x71 0x23 0x35 0x2b 0x00 0x00 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x1b 0x61 0x3c 0x5d 0x55 0xf 0x1a 0x3f 0x59 0x2b 0x65 0x2f 0x14 0x7 0x24 0x46 0x53 0xf 0x76 0x4f 0x7a 0x2 0x45 0x10 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x53 0x3 0x4f 0x42 0x47 0x35 0x4c 0x3b 0x6f 0x10 0x62 0x57 0x52 0x1d 0x37 0x4a 0x19 0x4c 0x6f 0x57 0x48 0x64 0x0 0x43 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0xc 0x62 0x39 0x14 0x7f 0x11 0x6b 0xe 0x1c 0x38 0x50 0x20 0x5f 0x61 0x1e 0x39 0x7c 0x1a 0x40 0x48 0x40 0x15 0x6e 0x53 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x5d 0x5c 0xc 0x27 0xf 0x8 0x72 0xa 0x77 0x3f 0x35 0x54 0xa 0x53 0x63 0x1f 0x80 0x36 0x51 0x20 0x4b 0x4c 0x26 0x3e 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x66 0x7 0x2b 0x7 0x27 0x5e 0x3e 0x8 0x6c 0x25 0x2a 0x17 0x69 0x63 0x1c 0x7 0x57 0x16 0x47 0x60 0x53 0x29 0xd 0x2 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x4e 0x4c 0x3a 0x2d 0x10 0x14 0x10 0x1b 0x33 0x1e 0x5e 0x21 0x26 0xa 0x4e 0x53 0x1d 0x7 0x11 0xe 0x1 0x5a 0x1d 0x4 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x53 0x3e 0xe 0x14 0x49 0x6 0x50 0x7 0x44 0x5a 0x11 0x40 0x69 0x32 0x38 0x20 0x6e 0x64 0x1d 0x28 0x51 0x31 0x3d 0x2b 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x5d 0x55 0x72 0x22 0x1f 0x56 0x6f 0x26 0x1f 0x5f 0x50 0x37 0x28 0x3 0x66 0x29 0x17 0x61 0x55 0x52 0x21 0x2a 0x63 0x11 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x21 0x54 0x1d 0x38 0x69 0x2a 0x28 0x29 0x17 0x37 0x34 0x45 0x8 0x47 0xa 0x49 0x20 0x7 0x70 0x5b 0x1b 0x54 0x73 0x15 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x1d 0x16 0x16 0x51 0x63 0x5d 0x23 0x16 0x2 0x60 0x45 0x37 0x68 0x3e 0x10 0x49 0x7c 0x54 0x41 0x2c 0x62 0x28 0x39 0x1e 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x5a 0x2b 0x6 0x29 0x5 0x15 0x38 0x2c 0x10 0x2a 0x60 0x40 0x4e 0x57 0x3a 0x53 0x31 0x13 0x5c 0x47 0x7 0x9 0x3c 0x16 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0xb 0x1a 0xb 0x42 0x26 0x46 0x71 0x1a 0x71 0x57 0x57 0x11 0x37 0x3f 0x5b 0x3f 0x12 0x55 0x64 0x35 0x36 0x28 0x60 0x2d 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x56 0x60 0x66 0x40 0x80 0x25 0x63 0x4d 0x16 0x1b 0x2a 0x42 0x67 0x16 0x3c 0x4a 0x46 0x33 0x18 0x6 0x5 0xc 0x64 0x5f 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x61 0x4d 0x4e 0x42 0x1b 0x4b 0xd 0x43 0x3b 0x47 0x4d 0x1f 0x13 0x4a 0x71 0x15 0x5c 0x1d 0x5 0x5f 0x5 0x26 0x6f 0x54 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x19 0x2e 0xd 0x15 0x13 0x24 0x26 0x13 0x46 0x17 0x35 0xa 0x66 0xf 0x52 0x52 0x75 0x50 0x50 0x4 0x52 0x61 0x22 0x21 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x3 0x24 0x48 0x1a 0x10 0x3a 0x43 0x4c 0x13 0x4e 0x14 0x6 0x39 0x6 0x72 0x53 0x30 0x10 0x13 0x1a 0x24 0x7 0x7c 0x59 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x6b 0x45 0x1 0x2d 0x66 0x5a 0x72 0x26 0x69 0x3b 0x3b 0x50 0x52 0x3 0x25 0x40 0x43 0x3b 0x21 0x40 0x3a 0x24 0x46 0x29 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x78 0xf 0x5d 0x6 0x37 0x3e 0x47 0x9 0x33 0x46 0x6b 0x3c 0x31 0x32 0x3c 0x43 0x16 0x40 0x5d 0x15 0x3f 0x4a 0x64 0x42 0x0 0x0 0xfc\n" +
            "0xfa 0xfb 0x1f 0x1 0xa1 0x20 0x5 0x5d 0x61 0x55 0x16 0x2a 0x3f 0x72 0x27 0x37 0x4 0x7d 0x51 0x53 0x3a 0x80 0xa 0x7a 0x17 0x42 0x56 0xe 0x28 0x0 0x0 0xfc\n";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initEvent();
    }

    private void initEvent() {
//        ArmorDeviceService.me().HS_SetPrecision(ArmorDeviceServiceInterface.MODULES_CLOTHING,20);
//        ArmorDeviceService.me().HS_Calibration(MODULES_CLOTHING);


        ArmorDeviceService.me().HS_Init();


        ArmorDeviceService.me().HS_DeviceStateChanged(new LPFN_HS_DeviceStateChanged() {
            @Override
            public void onResult(String address, boolean state) {
                BleLog.e(TAG, "HS_DeviceStateChanged " + state);
            }
        });
        ArmorDeviceService.me().HS_CalibrationCompleteResult(new LPFN_HS_CalibrationCompleteResult() {
            @Override
            public void onResult(int modules) {
                BleLog.e(TAG, "HS_CalibrationCompleteResult " + modules);
            }
        });
        ArmorDeviceService.me().HS_PowerResult(new LPFN_HS_GetPowerResult() {
            @Override
            public void onResult(int deviceMode, int power) {
                BleLog.e(TAG, "HS_PowerResult " + power);
            }
        });
        ArmorDeviceService.me().HS_SetArmorMoveResult(new LPFN_HS_ArmorMoveResult() {
            @Override
            public void onResult(double frontOrBack, double leftOrRight, double around) {
                BleLog.e(TAG, "HS_SetArmorMoveResult " + frontOrBack + " " + leftOrRight + " " + around);
            }
        });
        ArmorDeviceService.me().HS_PushButtonClick(new LPFN_HS_PushButtonClick() {
            @Override
            public void onResult(int buttonId, boolean state) {
                if (buttonId == DeviceEnum.LeftButton.value) {
                    BleLog.e(TAG, "HS_PushButtonClick 左侧" + buttonId + " " + state);
                } else if (buttonId == DeviceEnum.RightButton.value) {
                    BleLog.e(TAG, "HS_PushButtonClick 右侧" + buttonId + " " + state);
                }
            }
        });
        ArmorDeviceService.me().HS_PushButtonStick(new LPFN_HS_PushButtonStick() {
            @Override
            public void onResult(int buttonId) {
                BleLog.e(TAG, "HS_PushButtonStick " + buttonId);
            }
        });
        ArmorDeviceService.me().HS_InfraredEntry(new LPFN_HS_InfraredEntry() {
            @Override
            public void onResult(int buttonId, boolean state) {
                if (buttonId == DeviceEnum.LeftButton.value) {
                    BleLog.e(TAG, "HS_InfraredEntry 左侧" + buttonId + " " + state);
                } else if (buttonId == DeviceEnum.RightButton.value) {
                    BleLog.e(TAG, "HS_InfraredEntry 右侧" + buttonId + " " + state);
                }
            }
        });
        ArmorDeviceService.me().HS_InfraredSustained(new LPFN_HS_InfraredSustained() {
            @Override
            public void onResult(int buttonId) {
                if (buttonId == DeviceEnum.LeftInfrared.value) {
                    BleLog.e(TAG, "HS_InfraredSustained 左侧" + buttonId);
                } else if (buttonId == DeviceEnum.RightInfrared.value) {
                    BleLog.e(TAG, "HS_InfraredSustained 右侧" + buttonId);
                }
            }
        });
        ArmorDeviceService.me().HS_SetLegMoveResult(new LPFN_HS_LegMoveResult() {
            @Override
            public void onResult(int pos, double frontOrBack, double leftOrRight, double around) {
                if (pos == 0) {
                    BleLog.e(TAG, "HS_SetLegMoveResult 左腿 " + pos + "  " + frontOrBack + " " + leftOrRight + " " + around);
                } else if (pos == 1) {
                    BleLog.e(TAG, "HS_SetLegMoveResult 右腿" + pos + "  " + frontOrBack + " " + leftOrRight + " " + around);
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv1:
                runOnUiThread(() -> {
                    BleHelper.init(MainActivity.this, new BleInitCallback() {
                        @Override
                        public void onSuccess() {
                            Log.e(TAG, "初始化成功");
                        }

                        @Override
                        public void onFail(int code) {
                            Log.e(TAG, "初始化失败 " + code);
                        }
                    });
                });

                break;
            case R.id.tv2:
                BleHelper.startScan(new ScanCallback() {
                    @Override
                    public void onScanResult(BleRssiDevice bleRssiDevice) {
                        Log.e(TAG, "搜索到设备: address:" + bleRssiDevice.getBleAddress() + " name:" + bleRssiDevice.getBleName());
                    }
                });
                break;
            case R.id.tv3:
                BleHelper.stopScan();
                break;
            case R.id.tv4:
                BleHelper.connect(DEVICE_ADDRESS, new DeviceTransferCallback() {
                    @Override
                    public void onConnectionChanged(String address, int connectCode) {
                        Log.e(TAG, "onConnectionChanged : " + connectCode + " address :" + address);
                    }

                    @Override
                    public void onConnectFailed(String address, int errorCode) {
                        Log.e(TAG, "onConnectFailed  " + " address :" + address);
                    }

                    @Override
                    public void onConnectCancel(String address) {
                        Log.e(TAG, "onConnectCancel  ");
                    }

                    @Override
                    public void onNotifySuccess(String address) {
                        Log.e(TAG, "onNotifySuccess  ");
                    }

                    @Override
                    public void onWriteSuccess(String address) {
                        Log.e(TAG, "onWriteSuccess");
                    }

                    @Override
                    public void onWriteFailed(String address, int code) {
                        Log.e(TAG, "onWriteFailed : " + code);
                    }
                });
                break;
            case R.id.tv10:
                BleHelper.connect(DEVICE_ADDRESS_L_LEG, new DeviceTransferCallback() {
                    @Override
                    public void onConnectionChanged(String address, int connectCode) {
                        Log.e(TAG, "onConnectionChanged : " + connectCode + " address :" + address);
                    }

                    @Override
                    public void onConnectFailed(String address, int errorCode) {
                        Log.e(TAG, "onConnectFailed  " + " address :" + address);
                    }

                    @Override
                    public void onConnectCancel(String address) {
                        Log.e(TAG, "onConnectCancel  ");
                    }

                    @Override
                    public void onNotifySuccess(String address) {
                        Log.e(TAG, "onNotifySuccess  ");
                    }

                    @Override
                    public void onWriteSuccess(String address) {
                        Log.e(TAG, "onWriteSuccess");
                    }

                    @Override
                    public void onWriteFailed(String address, int code) {
                        Log.e(TAG, "onWriteFailed : " + code);
                    }
                });
                break;
            case R.id.tv11:
                BleHelper.connect(DEVICE_ADDRESS_R_LEG, new DeviceTransferCallback() {
                    @Override
                    public void onConnectionChanged(String address, int connectCode) {
                        Log.e(TAG, "onConnectionChanged : " + connectCode + " address :" + address);
                    }

                    @Override
                    public void onConnectFailed(String address, int errorCode) {
                        Log.e(TAG, "onConnectFailed  " + " address :" + address);
                    }

                    @Override
                    public void onConnectCancel(String address) {
                        Log.e(TAG, "onConnectCancel  ");
                    }

                    @Override
                    public void onNotifySuccess(String address) {
                        Log.e(TAG, "onNotifySuccess  ");
                    }

                    @Override
                    public void onWriteSuccess(String address) {
                        Log.e(TAG, "onWriteSuccess");
                    }

                    @Override
                    public void onWriteFailed(String address, int code) {
                        Log.e(TAG, "onWriteFailed : " + code);
                    }
                });
                break;
            case R.id.tv6:
                sendData();
//                BleHelper.writeData(new byte[]{});
                break;
            case R.id.tv7:
                BleHelper.disConnect();
                break;
            case R.id.tv8:
                // 震动1号马达，震动 20 * 100ms，震动幅度为50
                ArmorDeviceService.me().HS_SetArmorShake(0, 20, 50);
                // 1号马达停止震动
                ArmorDeviceService.me().HS_SetArmorShake(0, 0, 50);
                ArmorDeviceService.me().HS_ArmorShake();
                break;
            case R.id.tv9:
                ArmorDeviceService.me().HS_Init();
                BleLog.e(TAG, "HS_Calibration");
                ArmorDeviceService.me().HS_Calibration(0);
                ArmorDeviceService.me().HS_Calibration(1);
                ArmorDeviceService.me().HS_Calibration(2);
                break;
        }
    }

    private void sendData() {

        for (int i = 0; i <= 9; i++) {
            DEMO_DATA = DEMO_DATA.replaceAll("0x" + i + " ", "0x0" + i + " ");
        }
        for (char i = 'a'; i <= 'f'; i++) {
            DEMO_DATA = DEMO_DATA.replaceAll("0x" + i + " ", "0x0" + i + " ");
        }
        DEMO_DATA = DEMO_DATA.replaceAll("0x", "");
        DEMO_DATA = DEMO_DATA.replaceAll(" ", "");
        Log.e(TAG, DEMO_DATA);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2 * 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                String[] sendDatas = DEMO_DATA.split("\n");
                for (int i = 0; i < sendDatas.length; i++) {
                    byte[] sendata = ByteUtils.hexStr2Bytes(sendDatas[i]);
                    BleHelper.writeData(sendata);
                }
            }
        }).start();


    }

    private void initView() {
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        tv3 = findViewById(R.id.tv3);
        tv4 = findViewById(R.id.tv4);
        tv6 = findViewById(R.id.tv6);
        tv7 = findViewById(R.id.tv7);
        tv8 = findViewById(R.id.tv8);

        tv1.setOnClickListener(this);
        tv2.setOnClickListener(this);
        tv3.setOnClickListener(this);
        tv4.setOnClickListener(this);
        tv7.setOnClickListener(this);
        tv6.setOnClickListener(this);
        tv8.setOnClickListener(this);



        findViewById(R.id.tv9).setOnClickListener(this);
        findViewById(R.id.tv10).setOnClickListener(this);
        findViewById(R.id.tv11).setOnClickListener(this);
    }
}