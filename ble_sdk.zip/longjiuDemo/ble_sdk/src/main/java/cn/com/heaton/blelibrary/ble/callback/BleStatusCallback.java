package cn.com.heaton.blelibrary.ble.callback;

/**
 * description $desc$
 * created by jerry on 2019/7/22.
 */
public interface BleStatusCallback {
    void onBluetoothStatusChanged(boolean isOn);
}
