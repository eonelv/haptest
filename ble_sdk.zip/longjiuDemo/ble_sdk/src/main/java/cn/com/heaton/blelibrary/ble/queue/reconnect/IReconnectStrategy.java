package cn.com.heaton.blelibrary.ble.queue.reconnect;

/**
 * author: jerry
 * date: 21-1-9
 * email: superliu0911@gmail.com
 * des:
 */
public interface IReconnectStrategy {
    ReconnectStrategy strategy();
}
