package com.longjiu.ble.utils;

public class MathUtils {

    public static double Degree2Radian(double degree) {
        return degree / 180.0 * Math.PI;
    }

}
