package com.longjiu.ble.callback.add;

/**
 * 红外维持(level trigger mode)
 */
public interface LPFN_HS_InfraredSustained {
    void onResult(int buttonId);
}
