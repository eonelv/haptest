package com.longjiu.ble;

/**
 * @author Administrator
 * @description: TODO
 * @date 2023/8/31 0031 13:35
 */
public class AppConfig {
    public static final String SDK_VERSION = "v1.1";
}
