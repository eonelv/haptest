package com.longjiu.ble.model;

public enum DeviceState {
    Disconnected((char)1),
    Connected((char)2);

    DeviceState(char i) {
    }
}
