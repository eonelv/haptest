package com.longjiu.ble.callback.add;


/**
 * 按钮持续触摸(level trigger mode)
 */
public interface LPFN_HS_PushButtonStick {
    void onResult(int buttonId);
}
